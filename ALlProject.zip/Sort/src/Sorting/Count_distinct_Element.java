package Sorting;
import java.awt.RenderingHints.Key;
import java.util.*;
import java.util.Scanner;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Count_distinct_Element {

	public static void main(String[] args)
	{
		Scanner kb=new Scanner(System.in);
		int n=kb.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=kb.nextInt();	
		}
		
		List<Integer> value=new ArrayList<>();
		for(int i=0;i<n;i++)
		{
			value.add(arr[i]);
		}
		
		
		//Key key = Collections.max(value.entrySet(), Map.Entry.comparingByValue()).getKey();
		//Collections.max(value.entrySet(), Comparator.comparingInt(Map.Entry::getValue)).getKey();
		//Map<String, Long> result = animals.stream()
	   // .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		Map<Integer,Long> map=value.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		System.out.println(map);
	}
}
