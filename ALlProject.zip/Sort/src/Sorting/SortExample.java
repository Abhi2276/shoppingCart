package Sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class SortExample {
	
	public static void main(String[] args) {
		
	
	ArrayList<Emp> emps=new ArrayList<>();
	emps.add(new Emp(11,95,"juhi"));
	emps.add(new Emp(12,66,"saket"));
	emps.add(new Emp(13, 75,"abhi"));
	  List<Emp> out2=emps.stream().sorted(Comparator.comparing(Emp::getName)).collect(Collectors.toList());
	  
	  List<Emp> out3=emps.stream().sorted(Comparator.comparing(Emp::getMarks)).collect(Collectors.toList());
	  
	  
	  out2.forEach(e->System.out.println(e));
	  System.out.println(" ");
	  out3.forEach(e->System.out.println(e));
		/*
		 * Collections.sort(emps); System.out.println(emps);
		 */
}
}
