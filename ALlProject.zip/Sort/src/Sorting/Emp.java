package Sorting;

public class Emp implements Comparable<Emp> {

	int roll,marks;
	String name;
	
	@Override
	public int compareTo(Emp o) {
		
		return this.roll-o.roll;
	}
	
	
	public Emp(int roll, int marks, String name) {
		super();
		this.roll = roll;
		this.marks = marks;
		this.name = name;
	}
	
	                      
	
	
	public int getRoll() {
		return roll;
	}


	public void setRoll(int roll) {
		this.roll = roll;
	}


	public int getMarks() {
		return marks;
	}


	public void setMarks(int marks) {
		this.marks = marks;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	@Override
	public String toString() {
		return "Emp [roll=" + roll + ", marks=" + marks + ", name=" + name + "]";
	}
	
	
}


