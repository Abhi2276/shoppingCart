package Sorting;
import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class adding_no_in_list {
	public static void main(String[] args)
	{
		
	
	List<Integer> list=new ArrayList<>();
	list.add(45);
	list.add(76);
	list.add(33);
	list.add(11);
	list.add(11);
	
	List<Integer>res=list.stream().sorted().collect(Collectors.toList());
	System.out.print(res);
	HashSet<Integer>set=new HashSet<>();

 List<Integer>dub=list.stream().filter((e)->!set.add(e)).collect(Collectors.toList());
	
	System.out.println(dub);
	
	

}
}