package com.BlogApp.UserService;

import com.BlogApp.UserDto.CommentDto;

public interface CommentService {
	
	CommentDto createComment(CommentDto commentDto, Integer postId);
	
	void deleteComment(Integer CommentId);

}
