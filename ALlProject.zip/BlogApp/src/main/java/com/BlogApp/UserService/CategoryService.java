package com.BlogApp.UserService;

import java.util.List;

import com.BlogApp.UserDto.CategoryDto;
import com.BlogApp.entity.Category;

public interface CategoryService {
	
	CategoryDto createCategory(CategoryDto categoryDto);
	 
	CategoryDto updateCategory(CategoryDto categoryDto,Integer categoryId);
	
	public void deleteCategory(Integer categoryId);
	
	List<CategoryDto> getAllCategory();

	CategoryDto getCategory(Integer categoryId);
}
