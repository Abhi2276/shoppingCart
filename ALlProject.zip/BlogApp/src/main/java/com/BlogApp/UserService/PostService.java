package com.BlogApp.UserService;

import java.util.List;

import com.BlogApp.UserDto.PostDto;
import com.BlogApp.UserDto.PostResponse;
import com.BlogApp.entity.Category;
import com.BlogApp.entity.User;

public interface PostService {
	
	PostDto createPost(PostDto postdto, Integer userId, Integer postId);
	
	PostDto updatePost(PostDto postDto ,Integer postId);
	
	void deletePost(Integer postId);
	
	//List<PostDto> getAllPost(Integer PageNumber, Integer pageSize);
	
	PostResponse  getAllPost(Integer PageNumber, Integer pageSize,String sortBy,String sortDir);
	
	PostDto getPostById(Integer postId);
	
	List<PostDto> getPostByUser(Integer userId);
	
	List<PostDto> getPostByCategory(Integer categoryId);

}
