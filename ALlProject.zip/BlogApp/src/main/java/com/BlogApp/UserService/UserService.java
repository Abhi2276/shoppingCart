package com.BlogApp.UserService;

import java.util.List;

import com.BlogApp.UserDto.UserDto;

public interface UserService {
	
	
	 public UserDto CreateUser(UserDto user);
	 public UserDto UpdateUser(UserDto user,Integer userId);
	 public UserDto getUserById(Integer userId);
	 public List<UserDto> getAllUser();
	 public void deleteUser(Integer userId);

}
