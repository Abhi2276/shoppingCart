package com.BlogApp.UserDto;

public class CategoryDto {
	
	private Integer categoryId;
	
	
	private String categoryTitle;
	
	
	private String CategoryDescription;


	public CategoryDto(Integer categoryId, String categoryTitle, String categoryDescription) {
		super();
		this.categoryId = categoryId;
		this.categoryTitle = categoryTitle;
		CategoryDescription = categoryDescription;
	}


	public CategoryDto() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Integer getCategoryId() {
		return categoryId;
	}


	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}


	public String getCategoryTitle() {
		return categoryTitle;
	}


	public void setCategoryTitle(String categoryTitle) {
		this.categoryTitle = categoryTitle;
	}


	public String getCategoryDescription() {
		return CategoryDescription;
	}


	public void setCategoryDescription(String categoryDescription) {
		CategoryDescription = categoryDescription;
	}


	@Override
	public String toString() {
		return "CategoryDto [categoryId=" + categoryId + ", categoryTitle=" + categoryTitle + ", CategoryDescription="
				+ CategoryDescription + "]";
	}
	
	

}
