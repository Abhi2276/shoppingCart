package com.BlogApp.Security;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.BlogApp.Exception.ResourceNotFoundException;
import com.BlogApp.Repository.UserRepo;
import com.BlogApp.entity.User;


@Service
public class CustomUserDetailService implements UserDetailsService {

	@Autowired
	private UserRepo userRepo;
	
	
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// loading user from database by user
	User user=	 this.userRepo.findByEmail(username).orElseThrow(()-> new ResourceNotFoundException("user", "email", 0));
		
		return  user;
	}

	
}
