package com.BlogApp.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.BlogApp.UserDto.ApiResponse;
import com.BlogApp.UserDto.PostDto;
import com.BlogApp.UserDto.PostResponse;
import com.BlogApp.UserService.PostService;

@RestController
@RequestMapping("/api/")
public class PostController {

	@Autowired
	private PostService postService;
	
	
	@PostMapping("/user/{userId}/category/{categoryId}/posts")
	public ResponseEntity<PostDto> createPost(@RequestBody PostDto postDto,@PathVariable Integer userId, @PathVariable Integer categoryId)
	{
		
		PostDto createPost= this.postService.createPost(postDto, userId, categoryId);
		return new ResponseEntity<PostDto>(createPost,HttpStatus.CREATED);
	}
	
	@GetMapping("/posts")
	public ResponseEntity<PostResponse> getAllPost(@RequestParam(value="pageNumber",defaultValue ="1",required = false ) Integer pageNumber,
			                                        @RequestParam(value="pageSize",defaultValue = "3",required = false)Integer pageSize,
			                                        @RequestParam(value="sortBy",defaultValue = "postId",required=false)String sortBy,
			                                        @RequestParam(value = "sortDir",defaultValue = "asc",required=false) String sortDir)
	{
		//List<PostDto> allPost=this.postService.getAllPost(pageNumber,pageSize);
		//return new ResponseEntity<List<PostDto>>(allPost,HttpStatus.OK);
		PostResponse postResponse=this.postService.getAllPost(pageNumber, pageSize,sortBy,sortDir);
		
		return new ResponseEntity<PostResponse>(postResponse,HttpStatus.OK);
	}
	
	@GetMapping("/posts/{postId}")
	public ResponseEntity<PostDto> getPostById(@PathVariable Integer postId)
	{
		 PostDto singlePost=this.postService.getPostById(postId);
		
		return new ResponseEntity<PostDto>(singlePost,HttpStatus.OK);
	}
	
	@DeleteMapping("/posts/{postId}")
	public ApiResponse deletePost(@PathVariable Integer postId)
	{
		
		this.postService.deletePost(postId);
		return new ApiResponse(" post delete successfully deleted", true);
	}
	
	@PutMapping("/posts/{postId}")
	public ResponseEntity<PostDto> updatePost(@RequestBody PostDto postDto, @PathVariable Integer postid)
	{
		 PostDto updatedPost= this.postService.updatePost(postDto, postid);
		
		return new ResponseEntity<PostDto>(updatedPost, HttpStatus.OK);
	}
	
	
	@GetMapping("/user/{userId}/posts")
	public ResponseEntity<List<PostDto>> getPostsByUser(@PathVariable Integer userId)
	{
		List<PostDto> posts= this.postService.getPostByUser(userId);
		
		
		return new ResponseEntity<List<PostDto>>(posts,HttpStatus.OK);
	}
	
	
	@GetMapping("/category/{categoryId}/posts")
	public ResponseEntity<List<PostDto>> getPostByCategory(@PathVariable Integer categoryId)
	{
		List<PostDto> posts=this.postService.getPostByCategory(categoryId);
		return new ResponseEntity<List<PostDto>>(posts, HttpStatus.OK);
	}
	
}
