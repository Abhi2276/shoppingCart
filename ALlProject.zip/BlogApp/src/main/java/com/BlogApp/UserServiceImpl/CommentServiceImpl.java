package com.BlogApp.UserServiceImpl;

import com.BlogApp.UserDto.CommentDto;
import com.BlogApp.UserService.CommentService;
import com.BlogApp.entity.Comment;
import com.BlogApp.entity.Post;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BlogApp.Exception.ResourceNotFoundException;
import com.BlogApp.Repository.CommentRepo;
import com.BlogApp.Repository.PostRepo;


@Service
public class CommentServiceImpl implements CommentService {
	
	@Autowired
	private PostRepo postRepo;
	
	@Autowired
	private CommentRepo commentRepo;
	
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public CommentDto createComment(CommentDto commentDto, Integer postId) {
		
	Post post=	this.postRepo.findById(postId).orElseThrow(()-> new ResourceNotFoundException("post", "postId", postId));
	Comment comment=this.modelMapper.map(commentDto, Comment.class);
	comment.setPost(post);
	Comment savedComment=this.commentRepo.save(comment);
	return this.modelMapper.map(savedComment, CommentDto.class);
	
	
	
	}

	@Override
	public void deleteComment(Integer CommentId) {
Comment comment=this.commentRepo.findById(CommentId).orElseThrow(()-> new ResourceNotFoundException("comment", "commentId", CommentId));
		this.commentRepo.delete(comment);
		
	}

}
