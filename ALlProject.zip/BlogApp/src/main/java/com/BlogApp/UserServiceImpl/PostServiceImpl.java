package com.BlogApp.UserServiceImpl;

import java.awt.print.Pageable;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Sort;

import com.BlogApp.Exception.ResourceNotFoundException;
import com.BlogApp.Repository.CategoryRepo;
import com.BlogApp.Repository.PostRepo;
import com.BlogApp.Repository.UserRepo;
import com.BlogApp.UserDto.CategoryDto;
import com.BlogApp.UserDto.PostDto;
import com.BlogApp.UserDto.PostResponse;
import com.BlogApp.UserService.PostService;
import com.BlogApp.entity.Category;
import com.BlogApp.entity.Post;
import com.BlogApp.entity.User;


@Service
public class PostServiceImpl implements PostService {
	
	
	@Autowired
	private PostRepo postRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private CategoryRepo categoryRepo;
	
	
	@Autowired
	private UserRepo userRepo;

	@Override
	public PostDto createPost(PostDto postDto ,Integer userId,Integer categoryId) {
		 User user=this.userRepo.findById(userId).orElseThrow(()-> new ResourceNotFoundException("user", "UserId",userId));
		 Category category=this.categoryRepo.findById(categoryId).orElseThrow(()->new ResourceNotFoundException("Category", "CategoryId", categoryId));
		
		
		 Post post=this.modelMapper.map(postDto, Post.class);
		 post.setImageName("default.png");
		 post.setUser(user);
		 post.setCategory(category);
		  Post newpost=this.postRepo.save(post);
	      return  this.modelMapper.map(newpost, PostDto.class);
		 
		 
		
	}

	@Override
	public PostDto updatePost(PostDto postDto, Integer postId) {
		
		  Post post=this.postRepo.findById(postId).orElseThrow(()->new ResourceNotFoundException("Post", "PostId", postId));
		post.setTitle(postDto.getTitle());
		post.setContent(postDto.getContent());
		post.setImageName(postDto.getImageName());
		
		 Post updatedpost=this.postRepo.save(post);
		  
		  return this.modelMapper.map(updatedpost, PostDto.class);
	}

	@Override
	public void deletePost(Integer postId) {
		
	Post post=	this.postRepo.findById(postId).orElseThrow(()-> new ResourceNotFoundException("Post", "PostId", postId));
		 this.postRepo.delete(post);
	
	}

	@Override
	public PostResponse getAllPost(Integer pageNumber, Integer pageSize,String sortBy,String sortDir) {
	
		Sort sort=null;
		if(sortDir.equalsIgnoreCase("asc"))
		{
			sort=Sort.by(sortBy).ascending();
		}
		else
		{
			sort=Sort.by(sortBy).descending();
		}
		
		PageRequest p= PageRequest.of(pageNumber, pageSize,sort);
		//PageRequest p= PageRequest.of(pageNumber, pageSize,org.springframework.data.domain.Sort.by(sortBy).ascending());
	Page<Post>pagePost=this.postRepo.findAll(p);
		List<Post> allPost=pagePost.getContent();
	//List<Post> allPost	=this.postRepo.findAll();
	List<PostDto> postDtos=  allPost.stream().map((post)->this.modelMapper.map(post, PostDto.class)).collect(Collectors.toList());
		
	PostResponse postResponse =new PostResponse();
	postResponse.setContent(postDtos);
	postResponse.setPageNumber(pagePost.getNumber());
	postResponse.setPageSize(pagePost.getSize());
	postResponse.setTotalElements(pagePost.getTotalElements());
	postResponse.setTotalPages(pagePost.getTotalPages());
	postResponse.setLastPage(pagePost.isLast());
	

	return postResponse;
	}

	@Override
	public PostDto getPostById(Integer postId) {
	Post post=	this.postRepo.findById(postId).orElseThrow(()-> new ResourceNotFoundException("post", "postId", postId));
		return this.modelMapper.map(post, PostDto.class);
	}

	@Override
	public List<PostDto> getPostByUser(Integer userId) {
		
	User user=	this.userRepo.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User", "userId", userId));
	List<Post>posts=	this.postRepo.findByUser(user);
	 List<PostDto> postDtos=posts.stream().map((post)->this.modelMapper.map(post, PostDto.class)).collect(Collectors.toList());
	
	return postDtos;
	}

	@Override
	public List<PostDto> getPostByCategory(Integer  categoryId) {
	Category cat=	this.categoryRepo.findById(categoryId).orElseThrow(()-> new ResourceNotFoundException("category", "categoryId", categoryId));
		
	List<Post> posts=  this.postRepo.findByCategory(cat);
	List<PostDto> postDtos=posts.stream().map((post)->this.modelMapper.map(post, PostDto.class)).collect(Collectors.toList());
	
	return postDtos;
	}
	
	

}
