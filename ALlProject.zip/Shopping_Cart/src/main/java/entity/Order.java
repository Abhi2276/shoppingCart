package entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="myorder")
public class Order {
	
 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String orderDescription;
	
	@OneToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name="customer_id",referencedColumnName = "id")
	private Customer customer;
	
	
	@OneToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL,targetEntity = ShoppingCart.class)
	@JoinColumn(name="order_id",referencedColumnName = "id")
	private List<ShoppingCart> cartItem;


	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Order(String orderDescription, Customer customer, List<ShoppingCart> cartItem) {
		super();
		this.orderDescription = orderDescription;
		this.customer = customer;
		this.cartItem = cartItem;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getOrderDescription() {
		return orderDescription;
	}


	public void setOrderDescription(String orderDescription) {
		this.orderDescription = orderDescription;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public List<ShoppingCart> getCartItem() {
		return cartItem;
	}


	public void setCartItem(List<ShoppingCart> cartItem) {
		this.cartItem = cartItem;
	}


	@Override
	public String toString() {
		return "Order [id=" + id + ", orderDescription=" + orderDescription + ", customer=" + customer + ", cartItem="
				+ cartItem + "]";
	}
	
	
	
	
	
	
	
}
