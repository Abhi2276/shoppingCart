package empSort;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;


public class EmpSort {
	public static void main(String[] args)
	{
		
	
		Scanner kb=new Scanner(System.in);
		System.out.println("enter no  of emp to add:");
		int n=kb.nextInt();
	List<Emp> emp=new ArrayList<>();
	
	
	
	for(int i=0;i<n;i++)
	{
		System.out.println("enter the name");
		String name=kb.next();
		System.out.println("enter salary");
		int salary=kb.nextInt();
		System.out.println("Enter age");
		int age=kb.nextInt();
	
		emp.add(new Emp(name,salary,age));
	}
	
	List<Emp> out=emp.stream().sorted(Comparator.comparing(Emp::getName)).collect(Collectors.toList());
	
	System.out.println(out);
	
	
	
//	Map<Emp, Long> map=emp.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
//	System.out.println(map);
}
}

