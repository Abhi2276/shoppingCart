package com.Banking.CustomerRepo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Banking.Customer.Loan;

public interface LoanRepo extends JpaRepository<Loan, Integer> {
	

}
