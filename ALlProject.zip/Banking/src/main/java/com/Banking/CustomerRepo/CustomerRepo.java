package com.Banking.CustomerRepo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Banking.Customer.CustomerDetails;

public interface CustomerRepo  extends JpaRepository<CustomerDetails, Integer>{

}
