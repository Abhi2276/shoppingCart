package com.Banking.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Banking.CustomerDetailsDto.ApiResponse;
import com.Banking.CustomerDetailsDto.CustomerDetailsDto;
import com.Banking.CustomerService.CustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	@PostMapping("/")
	public ResponseEntity<CustomerDetailsDto> createCustomer(@Valid @RequestBody CustomerDetailsDto customerDetailsDto)
	{
		 CustomerDetailsDto createCus=this.customerService.createCustomer(customerDetailsDto);
		
		 return new ResponseEntity<CustomerDetailsDto>(createCus,HttpStatus.CREATED);
	}
	
	@PutMapping("/{cusId}")
	public ResponseEntity<CustomerDetailsDto> updateCustomer(@Valid @RequestBody CustomerDetailsDto customerDetailsDto,@PathVariable Integer cusId)
	{
		CustomerDetailsDto updatedCustomer=this.customerService.updateCustomer(customerDetailsDto, cusId);
		return new ResponseEntity<CustomerDetailsDto>(updatedCustomer,HttpStatus.OK);
	}
	
	@GetMapping("/")
	public ResponseEntity<List<CustomerDetailsDto>> getAllCustomer()
	{
		return ResponseEntity.ok(this.customerService.getAllCustomer()) ;
	}
	
	@GetMapping("/{cusId}")
	public ResponseEntity<CustomerDetailsDto> getCustomerById(@PathVariable Integer cusId)
	{
		return ResponseEntity.ok(this.customerService.getCustomerById(cusId));
	}
	
	@DeleteMapping("/{cusId}")
	public ResponseEntity<ApiResponse> deleteCustomer(@PathVariable Integer cusId)
	{
		this.customerService.deleteCustomer(cusId);
		return new ResponseEntity<ApiResponse>(new ApiResponse("Customer deleted successfully",true),HttpStatus.OK);
	}
	
	
	
}
