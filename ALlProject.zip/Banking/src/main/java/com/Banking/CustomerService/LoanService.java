package com.Banking.CustomerService;

import com.Banking.CustomerDetailsDto.LoanDto;

public interface LoanService {
	
public LoanDto personalLoad( LoanDto loanDto,Integer principal,Integer rate,Integer time);

public LoanDto homeLoan(Integer principal,Integer rate,Integer time);

public LoanDto carLoan(Integer principal,Integer rate,Integer time);

}
