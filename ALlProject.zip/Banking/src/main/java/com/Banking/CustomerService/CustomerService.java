package com.Banking.CustomerService;

import java.util.List;

import com.Banking.CustomerDetailsDto.CustomerDetailsDto;

public interface CustomerService {

	CustomerDetailsDto createCustomer(CustomerDetailsDto customerDetailsDto);
	
	CustomerDetailsDto updateCustomer( CustomerDetailsDto customerDetailsDto, Integer cusId);
	
	List<CustomerDetailsDto> getAllCustomer();
	
	CustomerDetailsDto getCustomerById(Integer cusId);
	
	void deleteCustomer(Integer cusId);
}
