package com.Banking.CustomerServiceImpl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

import com.Banking.Customer.Loan;
import com.Banking.CustomerDetailsDto.LoanDto;
import com.Banking.CustomerRepo.LoanRepo;
import com.Banking.CustomerService.LoanService;

public class LoanServiceImpl implements LoanService {
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private LoanRepo loanRepo;

	@Override
	public LoanDto personalLoad( LoanDto loanDto, Integer principal, Integer rate, Integer time) {
		
		
		int amount=principal*time;
		Loan rate1=this.modelMapper.map(loanDto, Loan.class);
		Loan loan=this.loanRepo.save(rate1);
		amount=this.loanRepo.save();
		
		
		return  this.modelMapper.map(loan, LoanDto.class);
	}

	@Override
	public LoanDto homeLoan(Integer principal, Integer rate, Integer time) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public LoanDto carLoan(Integer principal, Integer rate, Integer time) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
