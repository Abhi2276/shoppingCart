package com.Banking.CustomerServiceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Banking.Customer.CustomerDetails;
import com.Banking.CustomerDetailsDto.CustomerDetailsDto;
import com.Banking.CustomerRepo.CustomerRepo;
import com.Banking.CustomerService.CustomerService;
import com.Banking.Exception.ResourceNotFoundException;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerRepo customerRepo;
	
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public CustomerDetailsDto createCustomer(CustomerDetailsDto customerDetailsDto) {
		CustomerDetails cusdtl=this.modelMapper.map(customerDetailsDto,CustomerDetails.class );
		CustomerDetails addedcus=this.customerRepo.save(cusdtl);
		
		return this.modelMapper.map(addedcus, CustomerDetailsDto.class);
	}

	@Override
	public CustomerDetailsDto updateCustomer(CustomerDetailsDto customerDetailsDto, Integer cusId) {
	    
		CustomerDetails cusdtl=this.customerRepo.findById(cusId).orElseThrow(()->new ResourceNotFoundException("customer", "customerId", cusId));
		
		cusdtl.setName(customerDetailsDto.getName());
		cusdtl.setEmail(customerDetailsDto.getEmail());
		cusdtl.setPassword(customerDetailsDto.getPassword());
		
		CustomerDetails updatedDetails=this.customerRepo.save(cusdtl);
		
		
		return this.modelMapper.map(updatedDetails, CustomerDetailsDto.class);
	}

	@Override
	public List<CustomerDetailsDto> getAllCustomer() {
		List<CustomerDetails> cusdtl=this.customerRepo.findAll();
		List<CustomerDetailsDto>cusdtlDto= cusdtl.stream().map((cus)->this.modelMapper.map(cus, CustomerDetailsDto.class)).collect(Collectors.toList());
		return cusdtlDto;
	}

	@Override
	public CustomerDetailsDto getCustomerById(Integer cusId) {
CustomerDetails cusdtl=		this.customerRepo.findById(cusId).orElseThrow(()->new ResourceNotFoundException("Customer", "CustomerId",cusId));
		return this.modelMapper.map(cusdtl, CustomerDetailsDto.class);
	}

	@Override
	public void deleteCustomer(Integer cusId) {
		
	CustomerDetails cusdtl=	this.customerRepo.findById(cusId).orElseThrow(()->new ResourceNotFoundException("Customer", "CustomerId", cusId));
	
	this.customerRepo.delete(cusdtl);
	}

}
