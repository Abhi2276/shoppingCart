package com.Banking.CustomerDetailsDto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class CustomerDetailsDto {
	
	private int id;
	
	@NotEmpty
	@Size(min=4,max=10,message="name must be betwwen 4-8 char")
	private String name;
	
	@Email(message="email is not valid")
	private String email;
	
	@NotEmpty
	@Size(min=3,max=12,message="password must be between 3- 12 char")
	private String password;

	public CustomerDetailsDto(int id,
			@NotEmpty @Size(min = 4, max = 10, message = "name must be betwwen 4-8 char") String name,
			@Email(message = "email is not valid") String email,
			@NotEmpty @Size(min = 3, max = 12, message = "password must be between 3- 12 char") String password) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.password = password;
	}

	public CustomerDetailsDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "CustomerDetailsDto [id=" + id + ", name=" + name + ", email=" + email + ", password=" + password + "]";
	}
	
	

}
