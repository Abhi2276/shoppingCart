package com.Banking.CustomerDetailsDto;

import javax.validation.constraints.NotEmpty;

public class LoanDto {
	
@NotEmpty	
private  int principal;
	
   @NotEmpty
	private  int rate;
	
   @NotEmpty
	private int time;

public LoanDto(@NotEmpty int principal, @NotEmpty int rate, @NotEmpty int time) {
	super();
	this.principal = principal;
	this.rate = rate;
	this.time = time;
}

public LoanDto() {
	super();
	// TODO Auto-generated constructor stub
}

public int getPrincipal() {
	return principal;
}

public void setPrincipal(int principal) {
	this.principal = principal;
}

public int getRate() {
	return rate;
}

public void setRate(int rate) {
	this.rate = rate;
}

public int getTime() {
	return time;
}

public void setTime(int time) {
	this.time = time;
}

@Override
public String toString() {
	return "LoanDto [principal=" + principal + ", rate=" + rate + ", time=" + time + "]";
}
   
   
   


}
