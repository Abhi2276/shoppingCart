package com.Banking.Customer;

import javax.persistence.Entity;

@Entity
public class Loan {
	
	
	private  int principal;
	
	private  int rate;
	
	private int time;

	public Loan(int principal, int rate, int time) {
		super();
		this.principal = principal;
		this.rate = rate;
		this.time = time;
	}

	public Loan() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getPrincipal() {
		return principal;
	}

	public void setPrincipal(int principal) {
		this.principal = principal;
	}

	public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return "Loan [principal=" + principal + ", rate=" + rate + ", time=" + time + "]";
	}
	
	

}
