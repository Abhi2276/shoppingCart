package com.Json_Image;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassingFileJsonAtSametimeApplicationTests {

	@Test
	void contextLoads() {
	}

}
