package com.Json_Image;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PassingFileJsonAtSametimeApplication {

	public static void main(String[] args) {
		SpringApplication.run(PassingFileJsonAtSametimeApplication.class, args);
	}

}
