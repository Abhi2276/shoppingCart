package com.Json_Image.UserController;

import java.util.Arrays;

import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.Json_Image.User.User;

import ch.qos.logback.classic.Logger;

@RestController
@RequestMapping("/users")
public class UserController {

	private org.slf4j.Logger logger=LoggerFactory.getLogger(UserController.class);
	
	
	
	@PostMapping
	public ResponseEntity<?> addUserInformation(@RequestParam("file")MultipartFile file,
			                                    @RequestParam("userData")String userData)
	{
		
		this.logger.info("add user req");
		logger.info("fileInformation:{}",file.getOriginalFilename());
		logger.info("ussr:{}",userData);
		return ResponseEntity.ok("done");	
		
	}
	
	@PostMapping("/uploadImages")
	public ResponseEntity<?>uploadMultiplefile(@RequestParam("image")MultipartFile[] files)
	{
		
		this.logger.info("{} no of files uploaded",files.length);
		Arrays.stream(files).forEach((multipartFile)->{logger.info("filename",multipartFile.getOriginalFilename());
		                                               logger.info("filetype",multipartFile.getContentType());
		                                                });
		
		return ResponseEntity.ok("file uploaded");
	}
}
