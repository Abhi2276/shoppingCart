package com.Json_Image.UserController;

import java.util.Arrays;

import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import ch.qos.logback.classic.Logger;

@RestController
@RequestMapping("/image")
public class FileController {

	private org.slf4j.Logger logger=LoggerFactory.getLogger(FileController.class);
	
	@PostMapping("/uploadFiles")
	public ResponseEntity<?>uploadMultipleFile(@RequestParam("images")MultipartFile[] files)
	{
		this.logger.info("no of files uploaded" +files.length);
		Arrays.stream(files).forEach((multipartFile)->logger.info("filename{}",multipartFile.getOriginalFilename()));
		return ResponseEntity.ok(files.length+"files uploaded");
	}

}
