package stream;
import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;
public class Lambda_doubleCondition {

	
	public static void main(String[] args) {
		
		List<Employee>list=new ArrayList<>();
		list.add(new Employee(1,"ajay",22,500));
		list.add(new Employee(2,"anjali",25,1000));
		list.add(new Employee(3,"ram",18,200));
		list.add(new Employee(4,"abhi",8,700));
		//double condition lambda exp..
		List<Employee>res=list.stream().filter((e)->e.getName().startsWith("a")&&e.getAge()>20).collect(Collectors.toList());
		System.out.println(res);
		
		//displaying details of all empage>20
List<Employee>	agg=list.stream().filter((e)->e.getAge()>20).collect(Collectors.toList());
System.out.println(agg);

//displaying only age
for(int i=0;i<agg.size();i++)
{
	System.out.println(agg.get(i).getAge());
}

		//converting List object to map
		Map<String,Integer>map=new HashMap<>();
		for(Employee Emp:list)  //converting arraylist to Hashmap
		{
			map.put(Emp.getName(),Emp.getAge());
		}
		System.out.println(map);
		
	}

}
