package stream;

public class HashMapEmp {
	
	int id;
	String name;
	String book;
	public HashMapEmp(int id, String name, String book) {
		super();
		this.id = id;
		this.name = name;
		this.book = book;
	}
	@Override
	public String toString() {
		return "HashMapEmp [id=" + id + ", name=" + name + ", book=" + book + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBook() {
		return book;
	}
	public void setBook(String book) {
		this.book = book;
	}
	
	
	
	
	
	
	

}
