package stream;

import java.util.HashMap;
import java.util.Map;

public class HashMapx {

	public static void main(String[] args) {
		
		Map<Integer,String>map=new HashMap<>();
		 map.put(1, "Abhi");
		 map.put(2, " RAm");
		 map.put(3, "Rakesh");
		 map.put(4, " Jack");
		 map.put(5, " sai");
		 map.put(null, null);
		 map.put(6, null);
		 map.put(5, "amit");// replace with new value
		 map.put(null, "abc");
		
		 System.out.print(map);
		 
			 
		 //replace
		 
		// map.put(5, "amit");
	//	 System.out.println(map);
		 // remove
		 map.remove(4);   
		System.out.println(map);
		
		map.replace(2, " Abhirajj");
		System.out.println(map);
		 
		

	}

}
