package com.ApiCourse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiCourseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiCourseApplication.class, args);
	}

}
