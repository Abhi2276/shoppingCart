package com.ApiCourse.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ApiCourse.entity.Course;

public interface CourseDao extends JpaRepository<Course, Long> {

	
	
	
}
