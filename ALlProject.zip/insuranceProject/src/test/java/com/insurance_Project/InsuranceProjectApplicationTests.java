package com.insurance_Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
