package com.calculator;

import static org.assertj.core.api.Assertions.assertThat;

import org.hamcrest.text.IsEqualIgnoringCase;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class CalculatorApplicationTests {
 private Calculator c=new Calculator();
	@Test
	void contextLoads() {
	}

	@SuppressWarnings("deprecation")
	@Test
	void testSum()
	{
		int expectedresult=17;
		 int actualresult=c.doSum(12, 3, 2);
		 
		 assertThat(actualresult).isEqualTo(expectedresult);
	}
	
	@Test
	void testProduct()
	{
		int expectedresult=30;
		 int actualresult=c.doProduct(5, 6);
		 
		 assertThat(actualresult).isEqualTo(expectedresult);
	}
	
	@Test
	void testReverse()
	{
		String expected="ihba";
		String actual=c.doReverse("abhi");
		
		assertThat(actual).isEqualTo(expected);
	}
	
	
}
