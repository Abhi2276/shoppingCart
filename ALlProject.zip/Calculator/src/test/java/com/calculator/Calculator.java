package com.calculator;

public class Calculator {
public int doSum(int a,int b,int c)
{
	return a+b+c;
}

public int doProduct(int a,int b)
{
	return a*b;
}

public String doReverse(String s)
{
	String s1="";
	for(int i=s.length()-1;i>=0;i--)
	{
		char ch=s.charAt(i);
		 s1=s1+ch;
	}
	return s1;
}


}
