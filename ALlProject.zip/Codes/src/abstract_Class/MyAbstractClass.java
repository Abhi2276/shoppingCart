package abstract_Class;
import java.util.*;
 abstract public class MyAbstractClass {
	
	abstract void fun();
	{
		
	}

}
