package abstract_Class;

public class AbstractClassImpl extends MyAbstractClass {
	
	
	
	void fun()
	{
		System.out.println("derived method is called");
	}

	
	

}
