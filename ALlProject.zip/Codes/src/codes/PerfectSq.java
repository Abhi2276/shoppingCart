package codes;
import java.util.*;
public class PerfectSq {

	Scanner kb= new Scanner(System.in);
	String s=kb.next();
	
}
