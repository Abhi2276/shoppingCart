package encapsulation;

public class Emp2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Emp e2=new Emp();
		e2.setId(2);
		e2.setName("pratap");
		System.out.println(e2.getId());
		System.out.println(e2.getName());
		
		

	}

}
