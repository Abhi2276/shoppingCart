package test;
import java.util.*;
public class Sort {
//{0,0,1,1,1,2,2}   {0,1,2,2,1,1,0}
	public static void main(String[] args) {
		
int arr[]= {0,1,2,2,1,1,0};

List<Integer>list1=new ArrayList<>();

for(int i=0;i<arr.length;i++)
{
	if(arr[i]==0)
	{
		list1.add(arr[i]);
	}
}
List<Integer>list2=new ArrayList<>();
for(int i=0;i<arr.length;i++)
{
	if(arr[i]==1)
	{
		list2.add(arr[i]);
	}
}

List<Integer>list3=new ArrayList<>();
for(int i=0;i<arr.length;i++)
{
	if(arr[i]==2)
	{
		list3.add(arr[i]);
	}
}
System.out.println(list1);
System.out.println(list2);
System.out.println(list3);
//System.out.println(list1.addAll(list2));
list1.addAll(list2);
list1.addAll(list3);
System.out.println(list1);

//list1.addAll(list2);
//list2.addAll(list3);
//System.out.println(list1);

//for(int i=0;i<arr.length;i++)
//{
//	for(int j=0;j<arr.length-1;j++)
//	{
//		if(arr[j]>arr[j+1])
//		{
//			int temp=arr[j];
//			arr[j]=arr[j+1];
//			arr[j+1]=temp;
//		}
//	}
//}
//for(int i=0;i<arr.length;i++)
//{
//	System.out.println(arr[i]);
//}

	}

}



