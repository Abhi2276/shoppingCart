package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class EmployeeOperation {

	public static void main(String[] args) {
	
		List<Employee> list=new ArrayList<>();
		
		list.add( new Employee(1,"abhi",Arrays.asList("java","python")));
		
		list.add( new Employee(2,"ram",Arrays.asList("java","html")));
		
		list.add( new Employee(3,"shyam",Arrays.asList("c","python")));
		
		list.add(new Employee(4,"raghu",Arrays.asList("java","python")));
		
		//list.stream().collect(Collectors.groupingBy(Employee::getSkill())
		
		
		//list.stream().collect(Collectors.groupingBy(Employee::getSkill,Collectors.mapping(Employee::getEmpName,Collectors.toSet())));
		
		System.out.println(list);
		//list.forEach((e->e.stream().filter(e->e.getSkill().contains("java"))).collect(Collectors.toList());

//List<Employee> xxx=	list.forEach((e)->e.stream().filter(e->e.getSkill().contains("java"))).collect(Collectors.toList()));
		
//		Map<String,List<String>> map=new HashMap<>();
//		for(List<Employee> e:list)
//		{
//			map.put(null, null)
//		}
//		list.forEach((e)->e.stream().map()

	List<Employee>abc=	list.stream().filter((e)->e.getSkill().contains("java")).collect(Collectors.toList());
	System.out.println(abc);
		
Map<List<String>, Set<String>> res=		list.stream().collect(Collectors.groupingBy(Employee::getSkill,Collectors.mapping(Employee::getEmpName,Collectors.toSet())));
System.out.println(res);

list.stream().map(Employee::getSkill).forEach(System.out::print);//list of string
list.stream().flatMap(e->e.getSkill().stream()).forEach(System.out::println); // only string
	}

}
