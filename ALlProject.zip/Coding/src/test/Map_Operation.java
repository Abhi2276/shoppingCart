package test;

import java.util.stream.Collectors;
import java.util.*;
import java.util.Map.Entry;

import javax.print.attribute.HashAttributeSet;

public class Map_Operation {

	public static void main(String[] args) {

		
		Map<Integer,String>map=new HashMap<>();
		map.put(1, "rahul");
		map.put(3, "vijay");
		map.put(2, "ram");
		map.put(4, "avvc");
		
	
		//	map .entrySet() .stream() .sorted(comparingByValue()) .collect( toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2, LinkedHashMap::new));
		
		//max value in map
    Entry<Integer,String>res=  map.entrySet().stream().max((o1,o2)->o1.getValue().compareToIgnoreCase(o2.getValue())).get();
		System.out.println(res);

     //  map.entrySet().stream().sorted((o1,o2)->o1.getValue().compareToIgnoreCase(o2.getValue())).forEach(System.out::println);
     //  System.out.println(map);
       
       //sorting by key
       map.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(System.out::println);
       
      // sorting by value
       map.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);
       
       // value in hashmap contains particular character
        map.entrySet().stream().filter((e)->e.getValue().contains("r")).forEach(System.out::println);
        
        // starts with a
        map.entrySet().stream().filter((e)->e.getValue().startsWith("a")).forEach(System.out::println);
       
       
	}

}
