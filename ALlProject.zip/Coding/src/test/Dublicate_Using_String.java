package test;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;



public class Dublicate_Using_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//List<Integer>list=List.of(1,2,3,2,3,2,1,5);
		int arr[]= {1,2,3,4,2,1,5,6,4};
		List<Integer>list=new ArrayList<>();
		for(int i=0;i<arr.length;i++)
		{
			list.add(arr[i]);
		}
		HashSet<Integer>set=new HashSet<>();
List<Integer>res=		list.stream().filter((e)->!set.add(e)).collect(Collectors.toList());
System.out.println(res);
//count freq of character
Map<Integer,Long>map=list.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
System.out.println(map);
//max no
Integer maxno=list.stream().max((x,y)->x.compareTo(y)).get();
System.out.println(maxno);

//find 1 and last element
System.out.println(list.get(list.size()-1));
System.out.println(list.get(0));
	}

}
