package test;

import java.util.stream.Collectors;



import java.util.*;

public class Emp_Operation {
	public static void main(String[] args)
	{
		List<Emp>elist=new ArrayList<Emp>();
		elist.add(new Emp(1,"abhi",15000));
		elist.add(new Emp(2,"max",200000));
		elist.add(new Emp(3,"sam",388));
		elist.add(new Emp(4,"tac",50000));
		elist.add(new Emp(5,"aaa",15000));
		
		//name of emp having char m in name
	List<Emp> nameHavingm=	elist.stream().filter((e)->e.getName().contains("m")).collect(Collectors.toList());
		System.out.println(nameHavingm);
		
		
		//salary greater than 15000
		List<Emp>eres=elist.stream().filter((e)->e.getSalary()>15000).collect(Collectors.toList());
		System.out.println(eres);
		
		//name start with a
		List<Emp>res=elist.stream().filter((n)->n.getName().startsWith("a")).collect(Collectors.toList());
		System.out.println(res);
		
		//emp having max salary
	Emp e=	elist.stream().max(Comparator.comparing(Emp::getSalary)).get();
	System.out.println(e);
	
	//sorting by name
List<Emp>esort=	elist.stream().sorted(Comparator.comparing(Emp::getName)).collect(Collectors.toList());
System.out.println(esort);
System.out.print("----------");
//grouping name by salary
Map<Integer, Set<String>> grpby= elist.stream().collect(Collectors.groupingBy(Emp::getSalary,Collectors.mapping(Emp::getName,Collectors.toSet())));
System.out.println(grpby);

//grouping emp by salary
Map<Integer,List<Emp>> EmpBysal= elist.stream().collect(Collectors.groupingBy(Emp::getSalary));
System.out.println(EmpBysal);

//emp having sal=15000
 List<Emp>eqlsal=elist.stream().filter((x)->x.getSalary()==15000).collect(Collectors.toList());
 System.out.println(eqlsal);




 // List<Emp> aaa=elist.stream().filter((e)-e.getSalary().).collect(Collectors.toList());
  //System.out.println(aaa);
		
		
	}

}
